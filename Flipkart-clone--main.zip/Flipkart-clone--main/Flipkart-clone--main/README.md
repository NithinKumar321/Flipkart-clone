# Flipkart-clone-
The Flipkart static website using only HTML and CSS
![image](https://github.com/user-attachments/assets/54429762-5b38-4517-8778-f3cd41295e21)
